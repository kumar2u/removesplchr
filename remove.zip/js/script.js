function removeSpecificChars(text, charsToRemove) {
    // Add only the custom characters to the regex pattern
    const charsRegex = new RegExp(`[${charsToRemove.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')}]`, 'g');
    // Replace specified characters with a space
    text = text.replace(charsRegex, ' ');
    // Remove dots that are not part of a number
    text = text.replace(/(\d)\.(\d)/g, '$1DOT$2'); // Temporarily replace valid decimal points with 'DOT'
    text = text.replace(/\./g, ' '); // Remove all remaining dots
    text = text.replace(/DOT/g, '.'); // Restore valid decimal points
    return text.replace(/\s+/g, ' ').trim();
}

function updateCleanedText() {
    const text = document.getElementById('text').value;
    let charsToRemove = '';
    if (document.getElementById('customCheckbox').checked) {
        charsToRemove = document.getElementById('charsToRemove').value;
    }
    const cleanedText = removeSpecificChars(text, charsToRemove);
    document.getElementById('cleanedText').textContent = cleanedText;
}

document.getElementById('text').addEventListener('input', updateCleanedText);
document.getElementById('applyButton').addEventListener('click', updateCleanedText);

document.getElementById('customCheckbox').addEventListener('change', function() {
    if (this.checked) {
        document.getElementById('defaultCheckbox').checked = false;
        document.getElementById('customInputSection').style.display = 'block';
        document.getElementById('cleanedText').textContent = ''; // Clear the cleaned text area
    } else {
        document.getElementById('customInputSection').style.display = 'none';
        updateCleanedText(); // Update cleaned text when switching back to automatic removal
    }
});

document.getElementById('defaultCheckbox').addEventListener('change', function() {
    if (this.checked) {
        document.getElementById('customCheckbox').checked = false;
        document.getElementById('customInputSection').style.display = 'none';
        updateCleanedText();
    }
});
